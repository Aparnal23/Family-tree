// ================= SLIDE =================
function goToPage(pageIndex) {
    document.getElementById("slider").style.transform =
        `translateX(-${pageIndex * 100}vw)`;
}

// ================= COMMON FIT =================
function fitTree(g, nodes) {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

    nodes.forEach(d => {
        minX = Math.min(minX, d.x);
        maxX = Math.max(maxX, d.x);
        minY = Math.min(minY, d.y);
        maxY = Math.max(maxY, d.y);
    });

    const width = window.innerWidth - 40;
    const height = 700;
    const treeWidth = maxX - minX + 160;
    const treeHeight = maxY - minY + 100;
    const scaleX = width / treeWidth;
    const scaleY = height / treeHeight;
    const scale = Math.min(scaleX, scaleY, 1);
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    g.attr("transform",
        `translate(${width / 2}, ${height / 2}) scale(${scale}) translate(${-centerX}, ${-centerY})`
    );
}

// ================= PAGE 1 =================
const data1 = {
    name: "Chakki",
    children: [
        { name: "Eechamma" },
        {
            name: "Kaali",
            children: [
                {
                    name: "Raman",
                    children: [
                        { name: "Kunchiyan" },
                        { name: "Kochikavu" },
                        { name: "Neelamma" },
                        { name: "Kunchu Chakki" },
                        { name: "Kannan" },
                        { name: "Narayanan" }
                    ]
                }
            ]
        },
        { name: "Chakki" }
    ]
};

const svg1 = d3.select("#tree")
    .append("svg")
    .attr("width", "100%")
    .attr("height", 700);

const g1 = svg1.append("g");

const treeLayout1 = d3.tree().nodeSize([180, 120]);
const root1 = d3.hierarchy(data1);

treeLayout1(root1);
fitTree(g1, root1.descendants());

// LINKS
g1.selectAll(".link")
    .data(root1.links())
    .enter()
    .append("path")
    .attr("class", "link")
    .attr("d", d3.linkVertical()
        .x(d => d.x)
        .y(d => d.y + 25)
    );

// NODES
const node1 = g1.selectAll(".node")
    .data(root1.descendants())
    .enter()
    .append("g")
    .attr("class", "node")
    .attr("transform", d => `translate(${d.x},${d.y})`);

node1.append("rect")
    .attr("width", 150)
    .attr("height", 50)
    .attr("x", -75)
    .attr("y", -25)
    .attr("rx", 10);

node1.append("text")
    .attr("text-anchor", "middle")
    .attr("dy", "0.35em")
    .text(d => d.data.name);

// ❤️ Kaali + Raman
root1.descendants().forEach(d => {
    if (d.data.name === "Kaali" && d.children) {
        const raman = d.children[0];
        g1.append("text")
            .attr("x", (d.x + raman.x) / 2)
            .attr("y", (d.y + raman.y) / 2 - 20)
            .attr("text-anchor", "middle")
            .text("❤️");
    }
});

// ================= PAGE 2 =================
setTimeout(() => {

    const data2 = {
        name: "Neelamma",
        spouse: "Madhavan",
        children: [
            {
                name: "Kochummini",
                children: [
                    { name: "Sukumaran" },
                    { name: "Sathyadas" }
                ]
            },
            {
                name: "Kochu Govindan",
                children: [
                    { name: "Sukumaran" },
                    { name: "Dharmadas" },
                    { name: "Leela" },
                    { name: "Sudhakaran" },
                    { name: "Vijayan" },
                    { name: "Sathi" },
                    { name: "Radha" }
                ]
            },
            {
                name: "Bhavani",
                spouse: "Nanoo",
                children: [
                    {
                        name: "Vasanthi",
                        spouse: "Nanoo",
                        children: [{ name: "Anandababu" }]
                    },
                    {
                        name: "Sivanandan",
                        children: [
                            { name: "Thankamma", children: [{ name: "Shaji" }, { name: "Ajith" }, { name: "Jaya" }] }
                        ]
                    },
                    {
                        name: "Sarasamma",
                        children: [
                            { name: "Sankunni", children: [{ name: "Praksh" }, { name: "Sreeja" }, { name: "Pradeep" }, { name: "Sreela" }, { name: "Sreena" }] }
                        ]
                    },
                    {
                        name: "Sivarajan",
                        children: [
                            { name: "Sevini", children: [{ name: "Sunu" }, { name: "Shibu" }] }
                        ]
                    },
                    {
                        name: "Das",
                        children: [
                            { name: "Sukumari", children: [{ name: "Sreekanth" }, { name: "Gopakumar" }, { name: "Sinud" }] }
                        ]
                    },
                    { name: "Santhadevi", children: [{ name: "Sasi" }] },
                    {
                        name: "Sivaprasad",
                        children: [
                            { name: "Sobhana", children: [{ name: "Arun" }, { name: "Kiran" }, { name: "Varun" }] }
                        ]
                    }
                ]
            },

            {
                name: "Kamalakshi",
                children: [
                    { name: "Sreenivasan" },
                    { name: "Sreedevi" },
                    { name: "Sreekumar" }
                ]
            },
            {
                name: "Janardhanan",
                children: [
                    { name: "Bhasi" },
                    { name: "Sasidharan" },
                    { name: "Ravi" },
                    { name: "Suganthan" },
                    { name: "Soman" },
                    { name: "Manilal" },
                    { name: "Subash" },
                    { name: "Babu" }
                ]
            },
            {
                name: "Divakaran",
                children: [
                    { name: "Mohan Lal" },
                    { name: "Lailamani" },
                    { name: "Anitha" },
                    { name: "Lijin Lal" }
                ]
            }
        ]
    };

    const svg2 = d3.select("#tree2")
        .append("svg")
        .attr("width", "100%")
        .attr("height", 700);

    const g2 = svg2.append("g");

    const treeLayout2 = d3.tree().nodeSize([180, 120]);
    let root2 = d3.hierarchy(data2);

    // Collapse all nodes initially
    root2.descendants().forEach(d => {
        if (d.children) {
            d._children = d.children;
            d.children = null;
        }
    });

    update(root2);

    function update(source) {
        treeLayout2(root2);
        const nodes = root2.descendants();
        const links = root2.links();

        fitTree(g2, nodes);

        g2.selectAll("*").remove();

        // Links
        g2.selectAll(".link")
            .data(links)
            .enter()
            .append("path")
            .attr("class", "link")
            .attr("d", d3.linkVertical()
                .x(d => d.x)
                .y(d => d.y + 25)
            );

        // Nodes
        const node = g2.selectAll(".node")
            .data(nodes)
            .enter()
            .append("g")
            .attr("class", "node")
            .attr("transform", d => `translate(${d.x},${d.y})`)
            .on("click", click);

        node.append("rect")
            .attr("width", 150)
            .attr("height", 50)
            .attr("x", -75)
            .attr("y", -25)
            .attr("rx", 10)
            .attr("fill", d => d._children ? "#e3f2fd" : "#fff")
            .attr("stroke", "#000");

        node.append("text")
            .attr("text-anchor", "middle")
            .attr("dy", "0.35em")
            .text(d => d.data.name);

        // Dynamic hearts and spouses
        nodes.forEach(d => {
            // Dynamic spouses (Neelamma, Bhavani, Vasanthi)
            if (d.data.spouse && (d.data.showSpouse !== false)) {
                const spouseX = d.x + 180;
                const heartX = d.x + 90;
                g2.append("text")
                    .attr("x", heartX)
                    .attr("y", d.y)
                    .attr("text-anchor", "middle")
                    .attr("font-size", "20px")
            }
            // Keep Kaali-Raman for page1 consistency (if appears)
            if (d.data.name === "Kaali" && d.children) {
                const raman = nodes.find(n => n.parent === d && n.data.name === "Raman");
                if (raman) {
                    g2.append("text")
                        .attr("x", (d.x + raman.x) / 2)
                        .attr("y", (d.y + raman.y) / 2 - 20)
                        .attr("text-anchor", "middle")
                        .text("❤️");
                }
            }
            // Bhavani ❤️ Nanoo
            if (d.data.spouse && d.data.name === "Bhavani") {
                const spouseX = d.x + 180;
                const heartX = d.x + 90;
                g2.append("text")
                    .attr("x", heartX)
                    .attr("y", d.y)
                    .attr("text-anchor", "middle")
                    .attr("font-size", "20px")
                    .text("❤️")
                    .attr("class", "heart");
                g2.append("g")
                    .attr("class", "spouse-node")
                    .attr("transform", `translate(${spouseX},${d.y})`)
                  .append("rect")
                    .attr("width", 120)
                    .attr("height", 50)
                    .attr("x", -60)
                    .attr("y", -25)
                    .attr("rx", 10)
                    .attr("fill", "#fff3cd")
                    .attr("stroke", "#f39c12");
                g2.append("text")
                    .attr("x", spouseX)
                    .attr("y", d.y)
                    .attr("dy", "0.35em")
                    .attr("text-anchor", "middle")
                    .attr("font-weight", "600")
                    .text(d.data.spouse);
            }
        });
    }

    function click(event, d) {
        // Special handling for Vasanthi: toggle spouse Nanoo visibility
        if (d.data.name === "Vasanthi") {
            // Toggle spouse visibility using data flag
            if (!d.data.showSpouse) {
                d.data.showSpouse = true;
            } else {
                d.data.showSpouse = false;
            }
            update(d);
            return;
        }

        if (!d._children && !d.children) return;

        if (d.children) {
            d._children = d.children;
            d.children = null;
        } else {
            d.children = d._children;
            d._children = null;
        }

        update(d);
    }

}, 100);